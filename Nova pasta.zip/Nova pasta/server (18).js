// ==================== EXPOSE GLOBALS (session contract) ====================
// Declarar as funÃ§Ãµes/objetos globais esperados pelas sessÃµes aqui, sem
// alterar a lÃ³gica existente. Isso torna explÃ­cito o contrato entre a casca
// e as sessÃµes (canais, series, filmes), e facilita leitura/manutenÃ§Ã£o.
window.nav = window.nav || null;
window.navSeguro = window.navSeguro || null;
window.getSessoesValidas = window.getSessoesValidas || null;
window.sessaoExiste = window.sessaoExiste || null;
window.appState = window.appState || null;
window.appStates = window.appStates || null;
window.setAppState = window.setAppState || null; 

window.storage = window.storage || null;
window.idb = window.idb || null;
window.getOrCreateClientId = window.getOrCreateClientId || null;
window.getAuthData = window.getAuthData || null;
window.validateCredentials = window.validateCredentials || null;
window.validateProvider = window.validateProvider || null;
window.logout = window.logout || null;

window.ui = window.ui || null; // showLoading/hideLoading
window.showLoading = window.showLoading || null;
window.hideLoading = window.hideLoading || null;

window.carregarSessao = window.carregarSessao || null;
window.processarConteudoSessao = window.processarConteudoSessao || null;
window.cleanupCurrentSession = window.cleanupCurrentSession || null;

window.pushModal = window.pushModal || null;
  window.popModal = window.popModal || null;
  window.openModal = window.openModal || null;
  window.closeModal = window.closeModal || null;
  // window.sessionBackHandler serÃ¡ implementado no novo sistema BackControllerwindow.debug = window.debug || null;
window.search = window.search || null;
window.loadBrandingLogo = window.loadBrandingLogo || null;
window.getLogo = window.getLogo || null;

// ==================== CARREGAMENTO DINÃ‚MICO DOS PLAYERS ============
    // âœ… HLS.js carregado GLOBALMENTE para todas as sessÃµes
    var hlsScript = document.createElement('script');
    hlsScript.src = 'https://cdn.jsdelivr.net/npm/hls.js@latest';
    hlsScript.async = false;
    document.head.appendChild(hlsScript);

    // âœ… Video.js CSS carregado GLOBALMENTE
    var vjsCSS = document.createElement('link');
    vjsCSS.href = 'https://vjs.zencdn.net/8.5.2/video-js.css';
    vjsCSS.rel = 'stylesheet';
    document.head.appendChild(vjsCSS);

    // âœ… Video.js carregado GLOBALMENTE para sessÃµes de filmes e sÃ©ries
    var vjsScript = document.createElement('script');
    vjsScript.src = 'https://vjs.zencdn.net/8.5.2/video.min.js';
    vjsScript.async = false;
    document.head.appendChild(vjsScript);

    // ============ INÃCIO DO CÃ“DIGO ORIGINAL ============
    // âœ… ES5 PURO - VARIÃVEIS GLOBAIS
    var SESSAO_INICIAL = "index";
    var ENDPOINT = "https://webnoma.space/index/proxy.php";

    // ==================== SISTEMA DE ESTADOS DO APLICATIVO ====================
    
    /**
     * LÃ³gica do BotÃ£o 'Voltar' (Back)
     * Gerencia o comportamento do botÃ£o 'Voltar' do controle remoto,
     * implementando navegaÃ§Ã£o hierÃ¡rquica baseada no estado do aplicativo.
     */
    
    // DefiniÃ§Ã£o dos estados do aplicativo
    window.appState = 'STATE_HOME'; // Estado inicial
    window.appStates = {
        FULLSCREEN: 'STATE_FULLSCREEN',
        PLAYER_VIEW: 'STATE_PLAYER_VIEW',
        GRID_VIEW: 'STATE_GRID_VIEW',
        HOME: 'STATE_HOME',
        MODAL: 'STATE_MODAL'
    };

    // FunÃ§Ã£o de transiÃ§Ã£o de estado
    window.setAppState = function(newState) {
        if (Object.values(window.appStates).includes(newState)) {
            var previousState = window.appState;
            window.appState = newState;
            console.log('[APP STATE] ' + previousState + ' â†’ ' + newState);
        } else {
            console.error('[APP STATE] Estado invÃ¡lido:', newState);
        }
    };
    
    // === VARIÃVEL GLOBAL PARA MODAL ATUAL ===
window.currentOpenModal = null;

// === MAPEAMENTO MODAL â†’ FUNÃ‡ÃƒO DE FECHAMENTO ===
window.ModalMapper = {
    modalMap: {
        // === HOME ===
        'settings-modal': function() {
            console.log('ðŸ  Fechando settings modal (home)');
            if (typeof window.closeSettingsModal === 'function') {
                window.closeSettingsModal();
            }
        },
        'user-modal': function() {
            console.log('ðŸ  Fechando user modal');
            if (typeof window.closeUserModal === 'function') {
                window.closeUserModal();
            }
        },
        'parental-modal': function() {
            console.log('ðŸ  Fechando parental modal (home)');
            if (typeof window.closeParentalModal === 'function') {
                window.closeParentalModal();
            }
        },
        
        // === FILMES ===
        'moviesearch-modal': function() {
            console.log('ðŸŽ¬ Fechando search modal (filmes)');
            if (typeof window.closemovieSearchModal === 'function') {
                window.closemovieSearchModal();
            }
        },
        'history-modal': function() {
            console.log('ðŸŽ¬ Fechando history modal (filmes)');
            if (typeof window.closeHistoryModal === 'function') {
                window.closeHistoryModal();
            }
        },
        'filmes-settings-modal': function() {
            console.log('ðŸŽ¬ Fechando settings modal (filmes)');
            if (typeof window.closeSettingsModal === 'function') {
                window.closeSettingsModal();
            }
        },
        
        // === SERIES ===
        'search-modal': function() {
            console.log('ðŸ“º Fechando search modal (series)');
            if (typeof window.closeSearchModal === 'function') {
                window.closeSearchModal();
            }
        },
        'series-history-modal': function() {
            console.log('ðŸ“º Fechando history modal (series)');
            if (typeof window.closeHistoryModal === 'function') {
                window.closeHistoryModal();
            }
        },
        'favorites-modal': function() {
            console.log('ðŸ“º Fechando favorites modal');
            if (typeof window.closeFavoritesModal === 'function') {
                window.closeFavoritesModal();
            }
        },
        
        // === CANAIS ===
        'canais-settings-modal': function() {
            console.log('ðŸ“¡ Fechando settings modal (canais)');
            if (typeof window.closeSettingsModal === 'function') {
                window.closeSettingsModal();
            }
        },
        'program-preview-modal': function() {
            console.log('ðŸ“¡ Fechando program preview modal');
            if (typeof window.closeProgramPreview === 'function') {
                window.closeProgramPreview();
            }
        },
        'canais-parental-modal': function() {
            console.log('ðŸ“¡ Fechando parental modal (canais)');
            if (typeof window.cancelChannelParentalPassword === 'function') {
                window.cancelChannelParentalPassword();
            }
        },
        'menu-overlay': function() {
            console.log('ðŸ“¡ Fechando menu overlay');
            if (typeof window.closeChannelMenu === 'function') {
                window.closeChannelMenu();
            }
        }
    }
};

    // âœ… 1. SISTEMA DE STORAGE UNIFICADO - ES5
    window.storage = {
        // Para dados persistentes (credenciais, favoritos, configuraÃ§Ãµes)
        persistent: {
            set: function(key, data) {
                try {
                    localStorage.setItem(key, JSON.stringify(data));
                    return true;
                } catch (error) {
                    console.error('[STORAGE] âŒ localStorage cheio:', error);
                    return false;
                }
            },
            get: function(key) {
                try {
                    var data = localStorage.getItem(key);
                    return data ? JSON.parse(data) : null;
                } catch (error) {
                    console.error('[STORAGE] âŒ Erro localStorage:', error);
                    return null;
                }
            },
            remove: function(key) {
                try {
                    localStorage.removeItem(key);
                    return true;
                } catch (error) {
                    console.error('[STORAGE] âŒ Erro ao remover localStorage:', error);
                    return false;
                }
            },
            clear: function() {
                try {
                    localStorage.clear();
                    return true;
                } catch (error) {
                    console.error('[STORAGE] âŒ Erro ao limpar localStorage:', error);
                    return false;
                }
            }
        },
        
        // Para cache temporÃ¡rio (streams, categorias, EPG)
        temporary: {
            _cache: {},
            
            set: function(key, data, ttl) {
                ttl = ttl || 30 * 60 * 1000; // 30min default
                try {
                    var item = {
                        data: data,
                        expires: Date.now() + ttl
                    };
                    this._cache[key] = item;
                    return true;
                } catch (error) {
                    console.error('[STORAGE] âŒ Erro cache temporÃ¡rio:', error);
                    return false;
                }
            },
            
            get: function(key) {
                try {
                    var item = this._cache[key];
                    if (!item) return null;
                    
                    if (Date.now() > item.expires) {
                        delete this._cache[key];
                        return null;
                    }
                    
                    return item.data;
                } catch (error) {
                    console.error('[STORAGE] âŒ Erro ao ler cache:', error);
                    return null;
                }
            },
            
            clear: function() {
                this._cache = {};
                console.log('[STORAGE] ðŸ§¹ Cache temporÃ¡rio limpo');
            },
            
            cleanup: function() {
                // Remove itens expirados
                var now = Date.now();
                var keys = Object.keys(this._cache);
                var cleanedCount = 0;
                
                for (var i = 0; i < keys.length; i++) {
                    var key = keys[i];
                    var item = this._cache[key];
                    if (item.expires && now > item.expires) {
                        delete this._cache[key];
                        cleanedCount++;
                    }
                }
                
                if (cleanedCount > 0) {
                    console.log('[STORAGE] ðŸ§¹ Limpeza automÃ¡tica: ' + cleanedCount + ' itens expirados removidos');
                }
            }
        }
    };

    // ==================== UI HELPERS (Spinner / Loading) ====================
    // Expostos para que as sessÃµes (canais, series, filmes) possam reutilizar o
    // mesmo spinner padrÃ£o do index (marca Noma). Mantemos aliases para
    // compatibilidade com chamadas antigas.
    window.ui = window.ui || {};

    window.ui.showLoading = function(containerId, text) {
        try {
            var container = containerId ? document.getElementById(containerId) : document.getElementById('app');
            if (!container) return false;
            var safeText = text || '';
            var html = '' +
                '<div class="loading-container">' +
                  '<div class="logo-container">' +
                    '<img class="logo-img" src="https://webnoma.space/logos/nomaapp.png" alt="NomaApp"/>' +
                  '</div>' +
                  '<div class="spinner"></div>' +
                  '<div class="loading-progress">' + safeText + '</div>' +
                '</div>';
            container.innerHTML = html;
            return true;
        } catch (e) {
            console.warn('[UI] showLoading falhou:', e && e.message);
            return false;
        }
    };

    window.ui.hideLoading = function(containerId) {
        try {
            var container = containerId ? document.getElementById(containerId) : document.getElementById('app');
            if (!container) return false;
            // Remover apenas o loader, preservando outros conteÃºdos se houver
            var loader = container.querySelector('.loading-container');
            if (loader) loader.parentNode.removeChild(loader);
            return true;
        } catch (e) {
            console.warn('[UI] hideLoading falhou:', e && e.message);
            return false;
        }
    };

    // Backwards-compatible aliases
    window.showLoading = window.showLoading || window.ui.showLoading;
    window.hideLoading = window.hideLoading || window.ui.hideLoading;


    // âœ… 2. FUNÃ‡ÃƒO GLOBAL PARA CLIENT_ID ÃšNICO - ES5
    window.getOrCreateClientId = function() {
        var clientId = localStorage.getItem('client_id');
        if (!clientId) {
            // Gerar CLIENT_ID UUID v4 - ES5
            clientId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                var r = Math.random() * 16 | 0;
                var v = c === 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
            localStorage.setItem('client_id', clientId);
            console.log('[CASCA] âœ… CLIENT_ID gerado:', clientId);
        } else {
            console.log('[CASCA] âœ… CLIENT_ID encontrado:', clientId.substring(0, 8) + '...');
        }
        return clientId;
    };

    // âœ… 3. FUNÃ‡ÃƒO GLOBAL PARA AUTENTICAÃ‡ÃƒO - ES5
    window.getAuthData = function() {
        var usuario = localStorage.getItem("usuario");
        var senha = localStorage.getItem("senha");
        var dns = localStorage.getItem("dns");
        var provedor = localStorage.getItem("provedor");
        
        return {
            usuario: usuario,
            senha: senha,
            dns: dns,
            provedor: provedor,
            isAuthenticated: function() {
                return !!(this.usuario && this.senha && this.dns);
            }
        };
    };

    // âœ… 4. FUNÃ‡ÃƒO DE NAVEGAÃ‡ÃƒO ÃšNICA COM VALIDAÃ‡ÃƒO - ES5
    window.nav = function(destino) {
        console.log('[NAV] ðŸ“„ Navegando para: ' + destino);
        
        // Lista de sessÃµes vÃ¡lidas
        var SESSOES_VALIDAS = [
            'index',      // SessÃ£o inicial
            'login',      // PÃ¡gina de login  
            'autenticando', // ValidaÃ§Ã£o de credenciais
            'termos',     // Termos de uso
            'declined',   // SessÃ£o de termos recusados
            'home',       // PÃ¡gina principal
            'canais',     // Lista de canais
            'filmes',     // CatÃ¡logo de filmes
            'series',     // CatÃ¡logo de sÃ©ries
         
        ];
        
        // ValidaÃ§Ã£o do destino
        if (!destino) {
            console.error('[NAV] âŒ Destino de navegaÃ§Ã£o invÃ¡lido.');
            return false;
        }
        
        var isValidSession = false;
        for (var i = 0; i < SESSOES_VALIDAS.length; i++) {
            if (SESSOES_VALIDAS[i] === destino) {
                isValidSession = true;
                break;
            }
        }
        
        if (!isValidSession) {
            console.error('[NAV] âŒ SessÃ£o "' + destino + '" nÃ£o existe. SessÃµes vÃ¡lidas:', SESSOES_VALIDAS);
            console.warn('[NAV] âš ï¸ Tentando carregar "' + destino + '" mesmo assim...');
            // Continua tentando carregar - pode ser sessÃ£o nova que ainda nÃ£o foi adicionada Ã  lista
        }
        
        try {
            carregarSessao(destino);
            return true;
        } catch (error) {
            console.error('[NAV] âŒ Erro ao navegar para "' + destino + '":', error);
            return false;
        }
    };

    // âœ… 5. FUNÃ‡Ã•ES AUXILIARES DE NAVEGAÃ‡ÃƒO - ES5
    window.getSessoesValidas = function() {
        return [
            'index', 'login', 'autenticando', 'termos', 'declined', 
            'home', 'canais', 'filmes', 'series'
        ];
    };

    window.sessaoExiste = function(sessao) {
        var sessoesValidas = window.getSessoesValidas();
        for (var i = 0; i < sessoesValidas.length; i++) {
            if (sessoesValidas[i] === sessao) {
                return true;
            }
        }
        return false;
    };

    window.navSeguro = function(destino, fallback) {
        fallback = fallback || 'home';
        if (window.sessaoExiste(destino)) {
            return window.nav(destino);
        } else {
            console.warn('[NAV] âš ï¸ SessÃ£o "' + destino + '" nÃ£o existe, indo para "' + fallback + '"');
            return window.nav(fallback);
        }
    };

    // âœ… 6. FUNÃ‡ÃƒO DE VALIDAÃ‡ÃƒO DE CREDENCIAIS - ES5
    window.validateCredentials = function() {
        var authData = window.getAuthData();
        return authData.isAuthenticated();
    };

    // âœ… 7. FUNÃ‡ÃƒO DE VALIDAÃ‡ÃƒO DE PROVEDOR - ES5
    window.validateProvider = function() {
        var provedor = localStorage.getItem('provedor');
        var dns = localStorage.getItem('dns');
        return !!(provedor && dns);
    };

    // âœ… 8. FUNÃ‡ÃƒO DE LOGOUT GLOBAL - ES5
    window.logout = function() {
        try {
            // Limpar dados de autenticaÃ§Ã£o
            localStorage.removeItem('usuario');
            localStorage.removeItem('senha');
            localStorage.removeItem('dns');
            localStorage.removeItem('provedor');
            localStorage.removeItem('authenticated');
            localStorage.removeItem('auth_timestamp');
            
            // Limpar cache temporÃ¡rio
            window.storage.temporary.clear();
            
            console.log('[CASCA] ðŸšª Logout realizado');
            window.setAppState(window.appStates.HOME);
            window.nav('login');
        } catch (error) {
            console.error('[CASCA] âŒ Erro no logout:', error);
            // ForÃ§a navegaÃ§Ã£o mesmo com erro
            window.nav('login');
        }
    };

    // âœ… 9. FUNÃ‡ÃƒO GLOBAL PARA SISTEMA DE BRANDING - ES5
    window.loadBrandingLogo = function() {
        var logoImg = document.querySelector('#logoImg, .logo-img, .logo');
        var revendedorId = localStorage.getItem('revendedor_id');
        
        if (logoImg && revendedorId) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'https://webnoma.space/api/logo_proxy.php?id=' + revendedorId, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        logoImg.src = xhr.responseText;
                    } else {
                        logoImg.src = 'https://webnoma.space/logos/nomaapp.png';
                    }
                }
            };
            xhr.onerror = function() {
                logoImg.src = 'https://webnoma.space/logos/nomaapp.png';
            };
            xhr.send();
        } else {
            if (logoImg) {
                logoImg.src = 'https://webnoma.space/logos/nomaapp.png';
            }
        }
    };

    // âœ… 10. FUNÃ‡ÃƒO LEGACY PARA LOGO (MANTIDA PARA COMPATIBILIDADE) - ES5
    window.getLogo = function(callback) {
        try {
            // Verificar se revendedor_id existe no localStorage
            var revendedorId = localStorage.getItem("revendedor_id");
            
            if (!revendedorId) {
                console.warn('[LOGO] Revendedor ID nÃ£o encontrado, usando logo padrÃ£o');
                if (callback) callback("https://webnoma.space/logos/nomaapp.png");
                return;
            }
            
            // Fazer XMLHttpRequest para o proxy da logo
            var proxyURL = 'https://webnoma.space/api/logo_proxy.php?id=' + revendedorId;
            console.log('[LOGO] Buscando logo para revendedor: ' + revendedorId);
            
            var xhr = new XMLHttpRequest();
            xhr.open('GET', proxyURL, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var logoUrl = xhr.responseText.trim();
                        
                        // Validar se a URL retornada nÃ£o estÃ¡ vazia
                        if (!logoUrl || logoUrl === '') {
                            console.warn('[LOGO] âŒ URL da logo vazia');
                            if (callback) callback("https://webnoma.space/logos/nomaapp.png");
                            return;
                        }
                        
                        console.log('[LOGO] âœ… Logo personalizada encontrada: ' + logoUrl);
                        if (callback) callback(logoUrl);
                    } else {
                        console.warn('[LOGO] âŒ Erro HTTP: ' + xhr.status);
                        if (callback) callback("https://webnoma.space/logos/nomaapp.png");
                    }
                }
            };
            xhr.onerror = function() {
                console.warn('[LOGO] âŒ Erro de rede ao buscar logo personalizada');
                console.log('[LOGO] Usando logo padrÃ£o NomaApp');
                if (callback) callback("https://webnoma.space/logos/nomaapp.png");
            };
            xhr.send();
            
        } catch (error) {
            console.warn('[LOGO] âŒ Erro ao buscar logo personalizada:', error.message);
            console.log('[LOGO] Usando logo padrÃ£o NomaApp');
            if (callback) callback("https://webnoma.space/logos/nomaapp.png");
        }
    };

    // âœ… 11. FUNÃ‡ÃƒO DE LIMPEZA DE SESSÃƒO - ES5
    window.cleanupCurrentSession = function() {
        // FunÃ§Ã£o vazia por padrÃ£o - serÃ¡ substituÃ­da pelas sessÃµes
        console.log('[CASCA] ðŸ§¹ Cleanup de sessÃ£o chamado');
    };

    // âœ… 12. SISTEMA DE DEBUG CENTRALIZADO - ES5
    window.debug = {
        log: function(module, message, data) {
            data = data || '';
            var timestamp = new Date().toISOString().substr(11, 8);
            console.log('[' + timestamp + '] [' + module + '] ' + message, data);
        },
        
        navigation: function(from, to) {
            this.log('NAV', from + ' â†’ ' + to);
        },
        
        storage: function(operation, key, success) {
            var icon = success ? 'âœ…' : 'âŒ';
            this.log('STORAGE', icon + ' ' + operation + ': ' + key);
        },
        
        api: function(endpoint, method, success) {
            var icon = success ? 'âœ…' : 'âŒ';
            this.log('API', icon + ' ' + method + ' ' + endpoint);
        }
    };

    // âœ… 13. SISTEMA DE BUSCA UNIFICADO - ES5
    window.search = {
        // HistÃ³rico de buscas persistente
        history: {
            add: function(query, type, results) {
                var searches = window.storage.persistent.get('search_history') || [];
                var newSearch = {
                    query: query,
                    type: type, // 'canais', 'filmes', 'series'
                    timestamp: Date.now(),
                    results: results.slice(0, 5) // SÃ³ os 5 primeiros
                };
                searches.unshift(newSearch);
                
                // Manter apenas 50 buscas
                window.storage.persistent.set('search_history', searches.slice(0, 50));
            },
            
            get: function(type) {
                var searches = window.storage.persistent.get('search_history') || [];
                if (!type) return searches;
                
                var filtered = [];
                for (var i = 0; i < searches.length; i++) {
                    if (searches[i].type === type) {
                        filtered.push(searches[i]);
                    }
                }
                return filtered;
            },
            
            clear: function() {
                window.storage.persistent.set('search_history', []);
            }
        },
        
        // Cache de resultados temporÃ¡rio
        cache: {
            set: function(query, type, results) {
                var key = 'search_' + type + '_' + query.toLowerCase();
                window.storage.temporary.set(key, results, 10 * 60 * 1000); // 10min
            },
            
            get: function(query, type) {
                var key = 'search_' + type + '_' + query.toLowerCase();
                return window.storage.temporary.get(key);
            }
        },
        
        // FunÃ§Ã£o unificada de busca - ES5
        perform: function(query, type, callback) {
            console.log('[SEARCH] ' + type + ': "' + query + '"');
            
            // Verificar cache primeiro
            var cached = this.cache.get(query, type);
            if (cached) {
                console.log('[SEARCH] ðŸŽ¯ Cache hit para "' + query + '"');
                if (callback) callback(cached);
                return;
            }
            
            // Aqui seria implementada a busca real nos dados
            // Por enquanto retorna array vazio
            var results = [];
            
            // Salvar no cache e histÃ³rico
            this.cache.set(query, type, results);
            this.history.add(query, type, results);
            
            if (callback) callback(results);
        }
    };


    // ==================== ðŸš€ SMART TV BACK SYSTEM - ENTERPRISE EDITION ====================
    
    // === VARIÃVEL GLOBAL DE ESTADO + HISTÃ“RICO ===
    window.currentState = 'home';
    window.previousState = 'home';

    // Sistema de histÃ³rico de sessÃµes (mÃ¡ximo 2)
    window.SessionHistory = {
        get: function() {
            var history = sessionStorage.getItem('app_session_history');
            return history ? JSON.parse(history) : [];
        },
        
        add: function(sessionState) {
            var history = this.get();
            
            // Remove duplicatas - ES5
            var filtered = [];
            for (var i = 0; i < history.length; i++) {
                if (history[i] !== sessionState) {
                    filtered.push(history[i]);
                }
            }
            history = filtered;
            
            // Adiciona no inÃ­cio
            history.unshift(sessionState);
            
            // MantÃ©m mÃ¡ximo 2 sessÃµes
            if (history.length > 2) {
                history = history.slice(0, 2);
            }
            
            sessionStorage.setItem('app_session_history', JSON.stringify(history));
            console.log('ðŸ“š HistÃ³rico atualizado:', history);
        },
        
        getPrevious: function() {
            var history = this.get();
            return history.length > 1 ? history[1] : 'home';
        },
        
        getCurrent: function() {
            var history = this.get();
            return history.length > 0 ? history[0] : 'home';
        },
        
        clear: function() {
            sessionStorage.removeItem('app_session_history');
        }
    };

   // === SISTEMA BACK COMPLETO ===
window.AppBackSystem = {
    
    // ============================================
    // ðŸŽ§ MÃ“DULO: KEY LISTENER 
    // ============================================
    KeyListener: {
        backCodes: [461, 412, 174, 10009, 27, 8],
        backKeys: ['Back', 'GoBack', 'BrowserBack', 'Escape'],
        
        init: function() {
            console.log('ðŸŽ§ BackSystem KeyListener inicializado');
            
            document.addEventListener('keydown', function(e) {
                var keyCode = e.keyCode || e.which;
                var keyString = e.key;
                
                var isBackKey = false;
                for (var i = 0; i < window.AppBackSystem.KeyListener.backCodes.length; i++) {
                    if (window.AppBackSystem.KeyListener.backCodes[i] === keyCode) {
                        isBackKey = true;
                        break;
                    }
                }
                if (!isBackKey) {
                    for (var i = 0; i < window.AppBackSystem.KeyListener.backKeys.length; i++) {
                        if (window.AppBackSystem.KeyListener.backKeys[i] === keyString) {
                            isBackKey = true;
                            break;
                        }
                    }
                }
                
                if (isBackKey) {
                    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                        return;
                    }
                    
                    console.log('ðŸ”™ Back detectado: keyCode=' + keyCode + ', estado=' + window.currentState);
                    
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // VERIFICAÃ‡ÃƒO DE MODAL PRIMEIRO
                    console.log('[GLOBAL-BACK] Verificando modal:', window.modalAtivo);
                    if (window.modalAtivo === true) {
                        console.log('[GLOBAL-BACK] Modal detectado, fechando...');
                        window.closeCurrentModal();
                        return;
                    }
                    
                    // SE NÃƒO HÃ MODAL, EXECUTA NAVEGAÃ‡ÃƒO NORMAL
                    console.log('[GLOBAL-BACK] NavegaÃ§Ã£o normal');
                    window.AppBackSystem.StateMapper.execute();
                }
            }, true);
        }
    },
        // ============================================  
        // ðŸ—ºï¸ MÃ“DULO: STATE MAPPER
        // ============================================
        StateMapper: {
    stateMap: {
        // === HOME ===
        'home': function() {
            console.log('ðŸ  JÃ¡ estÃ¡ na home');
            // Poderia mostrar menu de saÃ­da ou fechar app
        },
        
        // === SÃ‰RIES ===
        'series_grid': function() {
            console.log('ðŸ“º Buscando sessÃ£o anterior no cache');
            var lastSession = window.BackCache.getLast();
            
            if (lastSession && lastSession !== 'series') {
                console.log('ðŸ”™ Voltando para sessÃ£o anterior:', lastSession);
                window.BackCache.consume(); // Consome a sessÃ£o
                window.nav(lastSession);
            } else {
                console.log('ðŸ  Sem sessÃ£o anterior, voltando para home');
                window.nav('home');
            }
        },
      //*//ries_seasons': function() {
        //  console.log('ðŸ“º Saindo das temporadas â†’ grade');
          // (typeof window.backToCategory === 'function') {
           // window.close
           // else {
            //*//indow.AppBackSystem.setState('series_grid');
           // */
       //,
        'series_episodes': function() {
            console.log('ðŸ“º Saindo dos episÃ³dios â†’ temporadas');
            if (typeof window.backToSeasonsList === 'function') {
                window.backToSeasonsList();
            } else {
                window.AppBackSystem.setState('series_seasons');
            }
        },
        'series_player': function() {
            console.log('ðŸ“º Saindo do player â†’ episÃ³dios');
            if (typeof closeSeriesPlayer === 'function') {
                closeSeriesPlayer();
            } else {
                window.AppBackSystem.setState('series_grid');
            }
        },
        'series_fullscreen': function() {
            console.log('ðŸ“º Saindo do fullscreen â†’ player');
            if (typeof window.toggleSeriesFullscreen === 'function') {
                window.toggleSeriesFullscreen();
            } else {
                window.AppBackSystem.setState('series_player');
            }
        },
        
        // === FILMES ===
        'filmes_grid': function() {
            console.log('ðŸŽ¬ Buscando sessÃ£o anterior no cache');
            var lastSession = window.BackCache.getLast();
            
            if (lastSession && lastSession !== 'filmes') {
                console.log('ðŸ”™ Voltando para sessÃ£o anterior:', lastSession);
                window.BackCache.consume(); // Consome a sessÃ£o
                window.nav(lastSession);
            } else {
                console.log('ðŸ  Sem sessÃ£o anterior, voltando para home');
                window.nav('home');
            }
        },
        'filmes_player': function() {
            console.log('ðŸŽ¬ Saindo do player â†’ grade');
            if (typeof window.backToMovieCategory === 'function') {
                window.backToMovieCategory();
            } else {
                window.AppBackSystem.setState('filmes_grid');
            }
        },
        'filmes_fullscreen': function() {
            console.log('ðŸŽ¬ Saindo do fullscreen â†’ player');
            if (typeof window.toggleMovieFullscreen === 'function') {
                window.toggleMovieFullscreen();
            } else {
                window.AppBackSystem.setState('filmes_player');
            }
        },
        
        // === CANAIS ===
        'canais_grid': function() {
            console.log('ðŸ“¡ Buscando sessÃ£o anterior no cache');
            var lastSession = window.BackCache.getLast();
            
            if (lastSession && lastSession !== 'canais') {
                console.log('ðŸ”™ Voltando para sessÃ£o anterior:', lastSession);
                window.BackCache.consume(); // Consome a sessÃ£o
                window.nav(lastSession);
            } else {
                console.log('ðŸ  Sem sessÃ£o anterior, voltando para home');
                window.nav('home');
            }
        },
        'canais_sidebar': function() {
            console.log('ðŸ“¡ Fechando sidebar â†’ grid');
            if (typeof window.showChannelCategories === 'function') {
               window.showChannelCategories();
            } else {
                window.AppBackSystem.setState('canais_grid');
            }
        },
       
        'canais_fullscreen': function() {
            console.log('ðŸ“¡ Saindo do fullscreen â†’ player');
            if (typeof window.toggleFullscreen === 'function') {
                window.toggleFullscreen();
            } else {
                window.AppBackSystem.setState('canais_sidebar');
            }
        }
    },
            execute: function() {
        var estadoAtual = window.currentState;
        var funcaoSaida = this.stateMap[estadoAtual];
        
        console.log('ðŸ—ºï¸ StateMapper executando: ' + estadoAtual);
        
        window.previousState = estadoAtual;
        
        if (funcaoSaida) {
            try {
                funcaoSaida();
            } catch (error) {
                console.error('âŒ Erro ao executar aÃ§Ã£o para estado "' + estadoAtual + '":', error);
                this.fallback();
            }
        } else {
            console.warn('âš ï¸ Estado "' + estadoAtual + '" nÃ£o mapeado, usando fallback');
            this.fallback();
        }
    },
    
    fallback: function() {
        console.log('ðŸ  Fallback: voltando para home');
        window.nav('home');
    }
},

        
      // ============================================
// ðŸ”§ UTILITÃRIOS GLOBAIS (RESTO IGUAL)
// ============================================

setState: function(novoEstado) {
    var estadoAnterior = window.currentState;
    window.currentState = novoEstado;
    
    console.log('ðŸ”„ Estado mudou: ' + estadoAnterior + ' â†’ ' + novoEstado);
},

goHome: function() {
    window.currentState = 'home';
    if (typeof window.nav === 'function') {
        window.nav('home');
    }
},

getDebugInfo: function() {
    return {
        currentState: window.currentState,
        previousState: window.previousState,
        backCache: {
            last: window.BackCache.getLast(),
            secondLast: window.BackCache.getSecondLast()
        },
        mappedStates: Object.keys(this.StateMapper.stateMap)
    };
},

init: function() {
    console.log('ðŸš€ Iniciando AppBackSystem Enterprise Edition');
    this.KeyListener.init();
    
    // Disponibiliza funÃ§Ãµes globalmente
    window.setState = this.setState.bind(this);
    window.getBackDebug = this.getDebugInfo.bind(this);
}
    };

    // ============================================
    // ðŸŽ¬ AUTO-INICIALIZAÃ‡ÃƒO  
    // ============================================
    document.addEventListener('DOMContentLoaded', function() { 
        window.AppBackSystem.init(); 
    });
    if (document.readyState !== 'loading') {
        window.AppBackSystem.init();
    }

    // ==================== CACHE DE NAVEGAÃ‡ÃƒO ====================
    window.BackCache = {
        _sessions: [],
        
        add: function(session) {
            // Remove se jÃ¡ existe
            var filtered = [];
            for (var i = 0; i < this._sessions.length; i++) {
                if (this._sessions[i] !== session) {
                    filtered.push(this._sessions[i]);
                }
            }
            this._sessions = filtered;
            
            // Adiciona no inÃ­cio
            this._sessions.unshift(session);
            
            // MantÃ©m mÃ¡ximo 2
            if (this._sessions.length > 2) {
                this._sessions = this._sessions.slice(0, 2);
            }
        },
        
        getLast: function() {
            return this._sessions.length > 0 ? this._sessions[0] : null;
        },
        
        getSecondLast: function() {
            return this._sessions.length > 1 ? this._sessions[1] : null;
        },
        
        consume: function() {
            return this._sessions.shift();
        },
        
        clear: function() {
            this._sessions = [];
        }
    };
   


    // âœ… 14. FUNÃ‡ÃƒO DE CARREGAMENTO DE SESSÃƒO - ES5
    function carregarSessao(sessao) {
        var app = document.getElementById("app");
        if (!app) {
            console.error('[SPA] âŒ Elemento #app nÃ£o encontrado no DOM');
            return;
        }

        console.log('[SPA] ðŸ“„ Carregando sessÃ£o: ' + sessao);
        window.debug.navigation(window.currentSession || 'inicial', sessao);
        
       
        try {
            // Limpar sessÃ£o anterior se existir
            if (typeof window.cleanupCurrentSession === 'function') {
                window.cleanupCurrentSession();
            }

            var xhr = new XMLHttpRequest();
            xhr.open('GET', ENDPOINT + '?page=' + sessao, true);
            xhr.setRequestHeader("Content-Type", "text/html; charset=UTF-8");
            
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var html = xhr.responseText;
                        processarConteudoSessao(html, sessao, app);
                    } else {
                        mostrarErroCarregamento(app, 'Erro HTTP: ' + xhr.status);
                        console.error('[SPA] âŒ Erro HTTP:', xhr.status);
                    }
                }
            };
            
            xhr.onerror = function() {
                mostrarErroCarregamento(app, 'Erro de conexÃ£o');
                console.error('[SPA] âŒ Erro de rede ao carregar sessÃ£o');
            };
            
            xhr.send();
            
        } catch (e) {
            mostrarErroCarregamento(app, 'Erro interno');
            console.error('[SPA] âŒ Erro ao carregar sessÃ£o:', e);
        }
    }

    // âœ… 15. FUNÃ‡ÃƒO PARA PROCESSAR CONTEÃšDO DA SESSÃƒO - ES5
    function processarConteudoSessao(html, sessao, app) {
        app.innerHTML = '';
        
        // Remover estilos de sessÃ£o anterior
        var sessionStyles = document.querySelectorAll('style[data-session-style]');
        for (var i = 0; i < sessionStyles.length; i++) {
            sessionStyles[i].remove();
        }

        var parser = new DOMParser();
        var doc = parser.parseFromString(html, 'text/html');

        // Processar estilos
        var styleElements = doc.querySelectorAll('style');
        for (var i = 0; i < styleElements.length; i++) {
            var newStyle = document.createElement('style');
            newStyle.setAttribute('data-session-style', sessao);
            newStyle.textContent = styleElements[i].textContent;
            document.head.appendChild(newStyle);
        }

        // Processar elementos do body
        var bodyChildren = doc.body.childNodes;
        for (var i = 0; i < bodyChildren.length; i++) {
            var node = bodyChildren[i];
            if (node.nodeType === Node.ELEMENT_NODE && node.tagName !== 'SCRIPT' && node.tagName !== 'STYLE') {
                app.appendChild(node.cloneNode(true));
            }
        }

        window.scrollTo(0, 0);

        // Processar scripts
        var scriptElements = doc.querySelectorAll('script');
        for (var i = 0; i < scriptElements.length; i++) {
            var newScript = document.createElement('script');
            newScript.textContent = scriptElements[i].textContent;
            document.body.appendChild(newScript);
        }

        var nomeFuncao = "inicializar" + sessao.charAt(0).toUpperCase() + sessao.slice(1);
        console.log('[SPA] ðŸŽ¯ Tentando executar: ' + nomeFuncao + '()');
        
        // Aguardar um pouco para garantir que o script foi processado
        setTimeout(function() {
            if (typeof window[nomeFuncao] === "function") {
                console.log('[SPA] âœ… Executando ' + nomeFuncao + '()...');
                window[nomeFuncao]();
                window.currentSession = sessao;
                
                // Definir estado padrÃ£o baseado na sessÃ£o
                if (sessao === 'home') {
                    window.setAppState(window.appStates.HOME);
                } else if (sessao === 'filmes' || sessao === 'series' || sessao === 'canais') {
                    window.setAppState(window.appStates.GRID_VIEW);
                }
            } else {
                console.warn('[SPA] âš ï¸ FunÃ§Ã£o ' + nomeFuncao + '() nÃ£o encontrada');
            }
        }, 100);
    }

    // âœ… 16. FUNÃ‡ÃƒO PARA MOSTRAR ERRO DE CARREGAMENTO - ES5
    function mostrarErroCarregamento(app, mensagem) {
        app.innerHTML = "<div style='display:flex; justify-content:center; align-items:center; height:100vh; font-size:18px; text-align:center;'>" +
                        "<div>" +
                        "<h3>Erro ao carregar conteÃºdo</h3>" +
                        "<p>" + mensagem + "</p>" +
                        "<p>Verifique sua conexÃ£o e tente novamente.</p>" +
                        "<button onclick='window.location.reload()' style='margin-top:20px; padding:10px 20px; background:#e94560; color:white; border:none; border-radius:5px; cursor:pointer;'>Recarregar</button>" +
                        "</div>" +
                        "</div>";
    }

    // âœ… 17. SISTEMA DE CLEANUP AUTOMÃTICO - ES5
    setInterval(function() {
        window.storage.temporary.cleanup();
    }, 5 * 60 * 1000); // Limpar cache expirado a cada 5 minutos

    // âœ… 18. FUNÃ‡ÃƒO DE FALLBACK PARA MODAIS/UTILITÃRIOS - ES5
    window.openModal = function(modal) {
        if (modal && typeof modal.classList !== 'undefined') {
            modal.classList.add('show');
            modal.style.display = 'flex';
            window.setAppState(window.appStates.MODAL);
            window.debug.log('MODAL', 'Abrindo modal: ' + (modal.id || 'sem-id'));
        }
    };
    

window.initApp = function() {
    console.log('[DEBUG] Testando endpoint:', ENDPOINT + '?page=index');
    
    var xhr = new XMLHttpRequest();
    xhr.open('GET', ENDPOINT + '?page=index', true);
    xhr.timeout = 10000; // 10s timeout
    
    xhr.onreadystatechange = function() {
        console.log('[DEBUG] ReadyState:', xhr.readyState, 'Status:', xhr.status);
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                console.log('[DEBUG] Resposta recebida:', xhr.responseText.substring(0, 200));
                processarConteudoSessao(xhr.responseText, 'index', document.getElementById('app'));
            } else {
                console.error('[DEBUG] Erro HTTP:', xhr.status, xhr.statusText);
            }
        }
    };
    
    xhr.onerror = function() {
        console.error('[DEBUG] Erro de rede');
    };
    
    xhr.ontimeout = function() {
        console.error('[DEBUG] Timeout - endpoint nÃ£o responde');
    };
    
    xhr.send();
};

    // FunÃ§Ã£o global para fechar um modal
window.closeModal = function(modalId) {
    console.log('ðŸŽ­ Fechando modal: ' + modalId);

    // Verifica se o modal atual Ã© o que estÃ¡ sendo fechado
    if (window.currentOpenModal === modalId) {
        window.currentOpenModal = null;
    }

    // Atualiza o estado do modal
    if (window.modalStates && window.modalStates.hasOwnProperty(modalId)) {
        window.modalStates[modalId] = false;
    } else {
        console.warn('âš ï¸ Modal nÃ£o mapeado: ' + modalId);
    }

    // Esconde o modal no DOM (se necessÃ¡rio)
    var modalElement = document.getElementById(modalId);
    if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
    }
};

    // âœ… 19. INFORMAÃ‡Ã•ES DO SISTEMA - ES5
    window.NomaTV = {
        version: '4.2-ES5-BackButton',
        build: Date.now(),
        features: {
            storage: true,
            navigation: true,
            search: true,
            debug: true,
            cleanup: true,
            logo: true,
            branding: true,
            backButton: true,
            es5Compatible: true
        },
        
        getInfo: function() {
            var clientId = localStorage.getItem('client_id');
            return {
                version: this.version,
                sessaoAtual: window.currentSession || 'nenhuma',
                estadoAtual: window.appState,
                clientId: clientId ? clientId.substring(0, 8) + '...' : 'nÃ£o-gerado',
                authenticated: window.validateCredentials(),
                cacheSize: Object.keys(window.storage.temporary._cache).length,
                features: this.features,
                sessoesValidas: window.getSessoesValidas()
            };
        }
    };

    // âœ… 20. LOG DE INICIALIZAÃ‡ÃƒO - ES5
    console.log('[CASCA] ðŸš€ NomaTV v4.2-ES5-BackButton - Sistema Unificado + BotÃ£o Voltar Carregado');
    console.log('[CASCA] âœ… FunÃ§Ãµes disponÃ­veis:', {
        nav: !!window.nav,
        getAuthData: !!window.getAuthData,
        storage: !!window.storage,
        search: !!window.search,
        debug: !!window.debug,
        getLogo: !!window.getLogo,
        loadBrandingLogo: !!window.loadBrandingLogo,
        setAppState: !!window.setAppState
    });
    console.log('[CASCA] ðŸŽ¯ SessÃµes vÃ¡lidas:', window.getSessoesValidas());
    console.log('[CASCA] ðŸŽ® Estados do app:', window.appStates);
    console.log('[CASCA] ðŸ“± Estado inicial:', window.appState);

    // FunÃ§Ã£o global para abrir um modal
window.openModal = function(modalId) {
    console.log('ðŸŽ­ Abrindo modal: ' + modalId);

    // Atualiza o modal atualmente aberto
    window.currentOpenModal = modalId;

    // Atualiza o estado do modal
    if (window.modalStates && window.modalStates.hasOwnProperty(modalId)) {
        window.modalStates[modalId] = true;
    } else {
        console.warn('âš ï¸ Modal nÃ£o mapeado: ' + modalId);
    }

    // Exibe o modal no DOM (se necessÃ¡rio)
    var modalElement = document.getElementById(modalId);
    if (modalElement) {
        modalElement.classList.add('show');
        modalElement.style.display = 'flex';
    }
};