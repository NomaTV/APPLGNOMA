-- =================================================================
-- MIGRAÇÃO PARA parent_id - NomaTV v4.5
-- =================================================================
-- 
-- OBJETIVO: Adicionar coluna parent_id e migrar dados do pattern matching
-- VERSÃO: 4.5 - Nova Lógica de Árvore Infinita
-- DATA: 01/08/2025
--
-- =================================================================

-- ✅ PASSO 1: ADICIONAR COLUNA parent_id
ALTER TABLE revendedores ADD COLUMN parent_id INT DEFAULT NULL;

-- ✅ PASSO 2: CRIAR ÍNDICE PARA PERFORMANCE
CREATE INDEX idx_parent_id ON revendedores(parent_id);

-- ✅ PASSO 3: MIGRAR DADOS EXISTENTES BASEADO NO PATTERN MATCHING ATUAL
-- Esta migração assume a estrutura atual dos IDs hierárquicos

-- Admin permanece com parent_id = NULL (raiz da árvore)
UPDATE revendedores 
SET parent_id = NULL 
WHERE master = 'admin';

-- ✅ PASSO 4: DEFINIR parent_id PARA REVENDEDORES CRIADOS PELO ADMIN
-- Exemplo: Se João (12345678) foi criado pelo Admin (10000000)
UPDATE revendedores 
SET parent_id = 10000000 
WHERE id_revendedor = '12345678';

-- ✅ PASSO 5: DEFINIR parent_id BASEADO NO PATTERN MATCHING ATUAL
-- Esta query migra automaticamente baseada na lógica de "últimos 4 dígitos"

-- Para revendedores cujo ID começa com "5678" (filhos do João 12345678)
UPDATE revendedores 
SET parent_id = 12345678 
WHERE id_revendedor LIKE '5678%' 
AND id_revendedor != '12345678' 
AND parent_id IS NULL;

-- ✅ EXEMPLO DE OUTRAS MIGRAÇÕES (AJUSTAR CONFORME SEUS DADOS)
-- Se há outros revendedores masters, replicar o padrão:

-- Exemplo: Se Maria (87654321) foi criada pelo Admin
-- UPDATE revendedores SET parent_id = 10000000 WHERE id_revendedor = '87654321';

-- Exemplo: Filhos da Maria (IDs que começam com 4321)
-- UPDATE revendedores SET parent_id = 87654321 WHERE id_revendedor LIKE '4321%' AND id_revendedor != '87654321';

-- ✅ PASSO 6: VERIFICAR INTEGRIDADE DOS DADOS MIGRADOS
-- Esta query mostra a estrutura hierárquica após a migração

SELECT 
    r.id_revendedor,
    r.nome,
    r.master,
    r.parent_id,
    CASE 
        WHEN r.parent_id IS NULL THEN 'RAIZ (Admin)'
        ELSE (SELECT p.nome FROM revendedores p WHERE p.id_revendedor = r.parent_id)
    END as criado_por,
    (SELECT COUNT(*) FROM revendedores filhos WHERE filhos.parent_id = r.id_revendedor) as total_filhos
FROM revendedores r 
WHERE r.ativo = 1
ORDER BY 
    CASE WHEN r.parent_id IS NULL THEN 0 ELSE 1 END, -- Admins primeiro
    r.parent_id,
    r.nome;

-- ✅ PASSO 7: VALIDAÇÃO - BUSCAR REGISTROS SEM parent_id DEFINIDO
-- (Exceto admins que devem ter parent_id = NULL)

SELECT 
    id_revendedor,
    nome,
    master,
    parent_id,
    '⚠️ ATENÇÃO: parent_id não definido' as status
FROM revendedores 
WHERE parent_id IS NULL 
AND master != 'admin' 
AND ativo = 1;

-- ✅ PASSO 8: CRIAR FUNÇÃO AUXILIAR PARA TESTAR BUSCA RECURSIVA
-- Esta query testa se a busca recursiva está funcionando corretamente

-- Exemplo: Buscar toda a rede do João (12345678)
WITH RECURSIVE rede_completa AS (
    -- Ponto inicial: João
    SELECT 
        id_revendedor,
        nome,
        parent_id,
        0 as nivel,
        CAST(id_revendedor AS TEXT) as caminho
    FROM revendedores 
    WHERE id_revendedor = '12345678'
    
    UNION ALL
    
    -- Recursão: todos os descendentes
    SELECT 
        r.id_revendedor,
        r.nome,
        r.parent_id,
        rc.nivel + 1,
        rc.caminho || ' -> ' || r.id_revendedor
    FROM revendedores r
    INNER JOIN rede_completa rc ON r.parent_id = rc.id_revendedor
    WHERE r.ativo = 1
)
SELECT 
    nivel,
    id_revendedor,
    nome,
    parent_id,
    caminho,
    '✅ Rede de João' as teste
FROM rede_completa 
ORDER BY nivel, nome;

-- ✅ PASSO 9: COMENTÁRIOS IMPORTANTES

-- 1. BACKUP: Sempre faça backup antes de executar esta migração!
-- 2. TESTE: Execute primeiro em ambiente de desenvolvimento
-- 3. VALIDAÇÃO: Verifique se todos os parent_id foram definidos corretamente
-- 4. PERFORMANCE: O índice idx_parent_id é crucial para queries recursivas

-- ✅ PASSO 10: EXEMPLO DE INSERÇÃO DE NOVOS REVENDEDORES (APÓS MIGRAÇÃO)
-- A partir de agora, todo novo revendedor deve ter parent_id preenchido automaticamente

-- Exemplo de como os endpoints atualizados vão inserir:
/*
INSERT INTO revendedores 
(id_revendedor, usuario, senha, nome, email, master, parent_id, plano, valor_mensal, limite_ativos, ativo, data_vencimento)
VALUES 
('56781003', 'carlos', 'hash_senha', 'Carlos Silva', 'carlos@teste.com', 'nao', '56781002', 'Básico', 60.00, 100, 1, '2025-12-31');
-- parent_id = 56781002 (Ana criou Carlos)
*/

-- =================================================================
-- FIM DA MIGRAÇÃO
-- =================================================================

-- ✅ VERIFICAÇÃO FINAL: Esta query deve mostrar a estrutura completa
SELECT 
    '📊 RESUMO PÓS-MIGRAÇÃO' as status,
    COUNT(*) as total_revendedores,
    SUM(CASE WHEN parent_id IS NULL THEN 1 ELSE 0 END) as total_raiz,
    SUM(CASE WHEN parent_id IS NOT NULL THEN 1 ELSE 0 END) as total_com_parent
FROM revendedores 
WHERE ativo = 1;